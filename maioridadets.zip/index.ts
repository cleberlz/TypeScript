let idade: number = 18;
let maioridade = idade >= 18;

if (maioridade) {
  console.log("Maior de idade");
} else {
  console.log("Menor de idade");
}