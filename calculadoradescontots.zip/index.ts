let valorproduto: number = 100;
let desconto: number = 10;

let valorfinal: number = valorproduto - (valorproduto * desconto / 100);

console.log("O valor final do produto com desconto de " + desconto + "% fica R$ " + valorfinal.toFixed(2));