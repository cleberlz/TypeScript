let temperatura: number = 20;
let celsius: boolean = true;
let result: number;

if (celsius) {
  result = (temperatura * 1.8) + 32;
  console.log("A temperatura é " + result + " graus Fahrenheit");    
} else {
  result = (temperatura -32) / 1.8;
  console.log("A temperatura é " + result + " graus Celsius");  
}