/*03. Crie uma interface "Produto" que tenha as propriedades "nome", "preco" e o método "calcularDesconto". Em seguida, crie uma classe "Livro" que implementa a interface "Produto" e tem um construtor que recebe nome e preço como parâmetros. Por fim, crie um objeto "meuLivro" a partir da classe e chame o método "calcularDesconto" para aplicar um desconto de 10%.*/

interface Produto{
  nome: string;
  preco: number;
  calcularDesconto(): number;
}

class Livro implements Produto{
  nome: string;
  preco: number;

  constructor(nome: string, preco: number){
    this.nome = nome;
    this.preco = preco;
  }

  calcularDesconto(): number{
    return (this.preco * 0.1);
  }
}

const meuLivro = new Livro("O Senhor dos Anéis", 50);

console.log("Livro: " + meuLivro.nome);
console.log("Preço sem desconto R$ " + meuLivro.preco.toFixed(2));
console.log("Desconto.......... R$ " + meuLivro.calcularDesconto().toFixed(2));
console.log("Preço com desconto R$ " + (meuLivro.preco - meuLivro.calcularDesconto()).toFixed(2));