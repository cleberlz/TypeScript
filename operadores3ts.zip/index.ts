const numero: number = 50;

const divisivelPorCinco: boolean = numero % 5 === 0;
console.log(divisivelPorCinco);