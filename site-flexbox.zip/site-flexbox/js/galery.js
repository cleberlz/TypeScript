// script.js
document.addEventListener('DOMContentLoaded', function () {
  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightbox = document.getElementById('lightbox');
  const lightboxContent = document.getElementById('lightbox-content');
  const close = document.getElementById('close');

  galleryItems.forEach(item => {
      item.addEventListener('click', function () {
          lightboxContent.src = this.src;
          lightbox.style.display = 'flex';
      });
  });

  close.addEventListener('click', function () {
      lightbox.style.display = 'none';
  });

  lightbox.addEventListener('click', function (e) {
      if (e.target !== lightboxContent) {
          lightbox.style.display = 'none';
      }
  });
});
