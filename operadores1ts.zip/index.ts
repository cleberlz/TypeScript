const numero: number = 20;

const divisivelPorDois: boolean = numero % 2 === 0;
console.log(divisivelPorDois);