const numero: number = 99;

const positivoMenorQue: boolean = numero >= 0 && numero < 100;
console.log(positivoMenorQue);