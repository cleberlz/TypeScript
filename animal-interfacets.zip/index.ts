/*02. Crie uma interface "Animal" que tenha a propriedade "especie" e o método "emitirSom". Em seguida, crie uma classe "Cachorro" que implementa a interface "Animal" e tem um construtor que recebe a espécie como parâmetro. Por fim, crie um objeto "meuCachorro" a partir da classe e chame o método "emitirSom".*/

interface Animal {
  especie: string;
  emitirSom(): void;
}

class Cachorro implements Animal {
  especie: string;

  constructor(especie: string) {
    this.especie = especie;
  }

  emitirSom(): void {
    console.log("Au au!");
  }
}

const meuCachorro = new Cachorro("Labrador");

meuCachorro.emitirSom();