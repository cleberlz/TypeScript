/*07. Crie uma interface chamada cursoTecnico (nome_aluno, quantidade_atividades, atividades_enviadas). Crie a função avaliacao (use a const resultado para armazenar os dados), dentro dessa função você deverá imprimir: nome_aluno, quantidade_atividades e se as atividades_enviadas forem >= do que 50% da quantidade_atividades escreva "APTO" caso contrário escreva "NÃO APTO". */

interface cursoTecnico {
  nome_aluno: string;
  quantidade_atividades: number;
  atividades_enviadas: number;
}

function avaliacao(cursoTecnico: cursoTecnico) {
  console.log(`Aluno: ${cursoTecnico.nome_aluno}`);
  console.log(`Qrde Atividades: ${cursoTecnico.quantidade_atividades}`);
  console.log(`Atividades Enviadas: ${cursoTecnico.atividades_enviadas}`);
  if (
    cursoTecnico.atividades_enviadas >=
    cursoTecnico.quantidade_atividades / 2
  ) {
    console.log("APTO");
  } else {
    console.log("NÃO APTO");
  }
}

const ct: cursoTecnico = {
  nome_aluno: "Cleber",
  quantidade_atividades: 100,
  atividades_enviadas: 49,
};

avaliacao(ct);
