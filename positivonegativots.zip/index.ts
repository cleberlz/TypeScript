let num : number = -100;

if (num >= 0) {
  console.log("O número " + num +" é positivo");
} else {
  console.log("O número " + num +" é negativo");
}

 