/* 
4. Criando uma classe Animal:
Crie uma classe Animal com um método fazerSom. Implemente o método fazerSom de forma específica para cada animal (fazer vários testes com animais diferentes).
*/
class Animal {
  nome: string;

  constructor(nome: string) {
    this.nome = nome;
  }

  fazerSom() {
    switch (this.nome) {
      case "Cavalo": {
        console.log("iiirrrrí, rilinchin");
        break;
      }
      case "Burro": {
        console.log("inhóóó inhóóó");
        break;
      }
      case "Cabra": {
        console.log("bééééééééééééééééééééé");
        break;
      }
      case "Cachorro": {
        console.log("au au au");
        break;
      }
      case "Gato": {
        console.log("miau");
        break;
      }
      case "Galo": {
        console.log("cocoricó, cocorocó");
        break;
      }
      case "Galinha": {
        console.log("cocó, cocorocó");
        break;
      }
      case "Macaco": {
        console.log("u u á á");
        break;
      }
      case "Peru": {
        console.log("glu glu glu");
        break;
      }
      case "Porco": {
        console.log("oinc oinc, iiihhh");
        break;
      }
      case "Pombo": {
        console.log("crruu crruu");
        break;
      }
      case "Pinto": {
        console.log("piu, piu");
        break;
      }
      case "Pato": {
        console.log("quá quá");
        break;
      }
      default: {
        console.log("Animal não encontrado");
        break;
      }
    }
  }
}

const a = new Animal("Pato");

a.fazerSom();
