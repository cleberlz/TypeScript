/*1. Criando um objeto Pessoa:
Crie uma classe Pessoa com os atributos nome, idade e cidade. Crie um construtor que inicializa os atributos e um método apresentar que imprime as informações da pessoa.*/

class Pessoa {
  // Atributos
  nome: string;
  idade: number;
  cidade: string;

  // Métodos
  constructor(nome: string, idade: number, cidade: string) {
    this.nome = nome;
    this.idade = idade;
    this.cidade = cidade;
  }

  apresentar() {
    console.log(
      `Olá, meu nome é ${this.nome}, tenho ${this.idade} anos e moro na cidade de ${this.cidade}.`,
    );
  }
}
// Criando um objeto da classe Pessoa
const cleber = new Pessoa("Cléber Zancanaro", 42, "Ivoti");

// Chamando um método do objeto
cleber.apresentar();
