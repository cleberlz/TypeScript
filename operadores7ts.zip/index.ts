const numero1: number = 7;
const numero2: number = 6;
const numero3: number = 5;

const media: boolean = (numero1 + numero2 + numero3) / 3;
console.log(media);