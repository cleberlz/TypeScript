/* 3. Crie a CLASSE NOTAS com os seguintes ATRIBUTOS/VARIAVEIS (nota1, nota2, nota3). Crie a CLASSE ALUNO com os ATRIBUTOS/VARIÁVEIS (nome_aluno, idade, media, resultado). A CLASSE ALUNO deverá herdar os atributos da CLASSE NOTAS. Desenvolva um método onde será armazenado na variável (resultado) a seguinte situação: média maior ou igual a 75 "APROVADO", senão "REPROVADO". Imprima no TERMINAL (nome_aluno, idade, nota1, nota2, nota3, media, resultado).*/

class Notas {
  nota1: number;
  nota2: number;
  nota3: number;
  constructor(nota1: number, nota2: number, nota3: number) {
    this.nota1 = nota1;
    this.nota2 = nota2;
    this.nota3 = nota3;
  }
  getNota1(): number {
    return this.nota1;
  }

  getNota2(): number {
    return this.nota2;
  }

  getNota3(): number {
    return this.nota3;
  }
}

class Alunos extends Notas {
  nome_aluno: string;
  idade: number;
  media: number;
  resultado: string;

  constructor(
    nome_aluno: string,
    idade: number,
    nota1: number,
    nota2: number,
    nota3: number,
  ) {
    super(nota1, nota2, nota3);
    this.nome_aluno = nome_aluno;
    this.idade = idade;
    this.media = this.calcularMedia();
    this.resultado = this.media >= 75 ? "APROVADO" : "REPROVADO";
    }

  calcularMedia() : number{
    return (this.nota1 + this.nota2 + this.nota3) / 3;
  }

  listar(){
    console.log(`Nome: ${this.nome_aluno}
                \nIdade: ${this.idade}
                \nNota 1: ${this.getNota1()}
                \nNota 2: ${this.getNota2()}
                \nNota 3: ${this.getNota3()}
                \nMédia: ${this.media.toFixed(1)}
                \nResultado: ${this.resultado}`)
  }
}

const alunos: Alunos[] = [
  new Alunos("João", 20, 80, 90, 70),
  new Alunos("Maria", 18, 40, 80, 50),
  new Alunos("Pedro", 19, 90, 80, 70),
  new Alunos("Cleber", 22, 75, 50, 60),
  new Alunos("Ana", 20, 70, 90, 80)];

for (const a of alunos) {
  a.listar();
  console.log("----------------------------------");
}
