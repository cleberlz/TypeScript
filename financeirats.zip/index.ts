/*4. Crie a CLASSE FINANCEIRA com os seguintes ATRIBUTOS/VARIÁVEIS (percentual_lucro). Crie a CLASSE BANCO com os ATRIBUTOS/VARIÁVEIS (nome_cliente, cpf, capital_aplicado, lucro). A CLASSE BANCO herdará os atributos da CLASSE FINANCEIRA. Desenvolva um método para apurar o lucro do cliente no BANCO. Imprima no TERMINAL (nome_cliente, cpf, capital_aplicado, lucro).*/

class Financeira {
  percentual_lucro: number;

  constructor(percentual_lucro: number) {
    this.percentual_lucro = percentual_lucro;
  }
}

class Banco extends Financeira {
  nome_cliente: string;
  cpf: number;
  capital_aplicado: number;
  lucro: number;

  constructor(
    nome_cliente: string,
    cpf: number,
    capital_aplicado: number,
    lucro: number,
    percentual_lucro: number,
  ) {
    super(percentual_lucro);
    this.nome_cliente = nome_cliente;
    this.cpf = cpf;
    this.capital_aplicado = capital_aplicado;
    this.lucro = this.apurar_lucro();
  }

  apurar_lucro(): number {
      return this.capital_aplicado * this.percentual_lucro / 100;
  }

  listar() {
    console.log(`Nome do cliente....: ${this.nome_cliente}
               \nCPF................: ${this.cpf}
               \nCapital aplicado...: R$ ${this.capital_aplicado.toFixed(2)}
               \nLucro..............: R$ ${this.lucro.toFixed(2)}
               \nPercentual de lucro: ${this.percentual_lucro.toFixed(2)}%`);
  }
}

const bancos: Banco[] = [
  new Banco("João", 12345678932, 1000, 0, 4.75),
  new Banco("Maria", 98765432198, 2000, 0, 11.67),
  new Banco("Pedro", 45678912309, 3000, 0, 7.95),
  new Banco("Ana", 78942345609, 4000, 0, 8.57),
];

for (const b of bancos) {
  b.listar();
  console.log("----------------------------------\n");
}
