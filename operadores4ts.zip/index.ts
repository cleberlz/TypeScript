const numero1: number = 5;
const numero2: number = 3;

const maiorQue: boolean = numero1 > numero2;
console.log(maiorQue);