let num1 = 5;
let num2 = 8;
let num3 = 2;

let result: number = num1;

if (num2 > num1){
  result = num2;
}

if (num3 > result){
  result = num3;
}

console.log('O maior número é ' + result);