let numero = 2;
let primo = true;

for (let i = 2; i < numero; i++) {

  if (numero % i === 0) {
    primo = false;
    break;
  }
}

if (primo){
  console.log("O número ", numero ," é primo");
} else {
  console.log("O número ", numero ," não é primo");
}