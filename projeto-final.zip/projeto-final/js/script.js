function validateForm() {
    let isValid = true;

    const nome = document.getElementById('nome').value;
    const telefone = document.getElementById('telefone').value;
    // Verifica se todos os campos obrigatórios estão preenchidos
    if (nome === "") {
        alert('Por favor, preencha o campo nome.');
        return false;
    }

    // Validação do e-mail
    const email = document.getElementById('email').value;
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        emailError.textContent = 'Por favor, insira um e-mail válido.';
        emailError.style.display = 'block';
        isValid = false;
    } else {
        emailError.textContent = '';
        emailError.style.display = 'none';
    }


    // Validação do CPF
    const cpf = document.getElementById('cpf').value;
    const cpfError = document.getElementById('cpfError');
    if (!cpf.match(/^\d{11}$/)) {
        cpfError.textContent = 'Por favor, insira um CPF válido (11 dígitos).';
        cpfError.style.display = 'block';
        isValid = false;
    } else {
        cpfError.textContent = '';
        cpfError.style.display = 'none';
    }

    if (telefone === "") {
        alert('Por favor, preencha o campo telefone.');
        return false;
    }

    return isValid;
}

function validateLogin() {
    const username = document.getElementById('usuario').value;
    const password = document.getElementById('senha').value;

    // Verifica se todos os campos obrigatórios estão preenchidos
    if (username === "" || password === "") {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return false;
    }

    if (username === "cleber" & password === "123") {
        alert('Login efetuado com sucesso.');
        return true;
    } else {
        alert('Usuário ou senha inválido.');
        return false;
    }
    return true;
}

var content = document.getElementById('fontSize');

function increaseFontSize() {
    var fontSize = window.getComputedStyle(content, null).getPropertyValue('font-size');
    var currentSize = parseFloat(fontSize);
    content.style.fontSize = (currentSize + 2) + 'px';
}

function decreaseFontSize() {
    var fontSize = window.getComputedStyle(content, null).getPropertyValue('font-size');
    var currentSize = parseFloat(fontSize);
    content.style.fontSize = (currentSize - 2) + 'px';
}

var increaseButton = document.getElementById('increase-button');
var decreaseButton = document.getElementById('decrease-button');

increaseButton.addEventListener('click', increaseFontSize);
decreaseButton.addEventListener('click', decreaseFontSize);


// botao

function onSignIn(googleUser) {
    var profile = googleUser.getBasicProfile();
    console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
    console.log('Name: ' + profile.getName());
    console.log('Image URL: ' + profile.getImageUrl());
    console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
}

function renderButton() {
    gapi.signin2.render('google-signin-button', {
        'scope': 'profile email',
        'width': 240,
        'height': 50,
        'longtitle': true,
        'theme': 'dark',
        'onsuccess': onSignIn,
        'onfailure': function(error) {
            console.log(JSON.stringify(error, undefined, 2));
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    gapi.load('auth2', function() {
        gapi.auth2.init().then(function() {
            renderButton();
        });
    });
});


