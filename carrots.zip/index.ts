/*
3. Criando uma classe Carro:
Crie uma classe Carro com os atributos marca, modelo e ano. Crie um método ligar que imprime uma mensagem "Carro ligado!".
*/

class Carro{
  marca: string;
  modelo: string;
  ano: number;

  constructor(marca: string, modelo: string, ano: number){
    this.marca = marca;
    this.modelo = modelo;
    this.ano = ano;
  }
  ligar(){
    console.log("Carro ligado!");
  }
}

let c = new Carro("Ford", "Fiesta", 2015);
c.ligar();