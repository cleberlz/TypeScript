/*06. Desenvolva uma classe chamada mercado. Crie uma interface chamada produtos (nome_produto, quantidade). Crie uma função chamada listarProduto. Dentro dessa função você deverá imprimir na tela o nome_produto e se a quantidade for maior do que 50 (variável quantidade + " Produtos em Estoque") senão imprima na tela (nome_produto + quantidade + " Produtos, Renovar Estoque").  */

interface Produtos {
  nome_produto: string;
  quantidade: number;
}

function listarProduto(produtos: Produtos) {
  if (produtos.quantidade > 50) {
    console.log(`Produto: ${produtos.nome_produto} 
    \nProdutos em Estoque`);
  } else {
    console.log(`Produto: ${produtos.nome_produto}
        \nEstoque: ${produtos.quantidade} 
        \nProdutos, Renovar Estoque`
    );
  }
}

const mercado: Produtos = {
  nome_produto: "Arroz",
  quantidade: 50,
};

listarProduto(mercado);
