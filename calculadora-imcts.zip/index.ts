let peso : number = 80;
let altura : number = 1.75;

let imc : number = (peso / (altura * altura)).toFixed(1);

if (imc < 18.5){
  console.log('Seu IMC é de ' + imc + ' = baixo peso');
} else if (imc >= 18.5 && imc < 25) {
  console.log('Seu IMC é de ' + imc + ' = normal');
} else if (imc >= 25 && imc < 30) {
  console.log('Seu IMC é de ' + imc + ' = sobrepeso');
} else if (imc >= 30 && imc < 35) {
  console.log('Seu IMC é de ' + imc + ' = obesidade');
} else if (imc >= 35 && imc < 40) {
  console.log('Seu IMC é de ' + imc + ' = obesidade severa');
} else {
  console.log('Seu IMC é de ' + imc + ' = obesidade mórbida');
}

