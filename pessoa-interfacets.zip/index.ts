/*01. Crie uma interface "Pessoa" que tenha as propriedades "nome" e "idade". Em seguida, crie uma classe "Aluno" que implementa a interface "Pessoa" e tem um construtor que recebe nome e idade como parâmetros. Por fim, crie um objeto "novoAluno" a partir da classe e imprima no console o seu nome e idade. */

interface Pessoa {
  nome: string;
  idade: number;
}

class Aluno implements Pessoa {
  constructor(nome: string, idade: number) {
    this.nome = nome;
    this.idade = idade;
  }

}

const novoAluno = new Aluno("João", 20);

console.log(`Nome: ${novoAluno.nome} - Idade: ${novoAluno.idade}`);



