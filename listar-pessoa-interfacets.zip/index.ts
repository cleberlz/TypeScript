/*05. Desenvolva uma interface chamada pessoa (nome, cpf, idade, email). Crie a função listar (imprima na tela o nome, cpf, idade e email).  */

interface Pessoa{
  nome: string;
  cpf: number;
  idade: number;
  email: string;
}

function listar(pessoa: Pessoa){
  console.log("Nome: " + pessoa.nome);
  console.log("CPF: " + pessoa.cpf);
  console.log("Idade: " + pessoa.idade);
  console.log("E-mail: " + pessoa.email);
}

let pessoa: Pessoa = {
  nome: "Cleber",
  cpf: 12345,
  idade: 33,
  email: "teste@example.com"
}

listar(pessoa);