/*04. Desenvolva uma interface chamada produtos (nome_produto, quantidade, preco_compra). Crie a função listar_produtos (imprima na tela o nome_produto, quantidade, preco_compra).  */

interface Produto {
  nome_produto: string;
  quantidade: number;
  preco_compra: number;
}

function listar_produtos(produtos: Produto[]) {
  for (const produto of produtos) {
    console.log(
      `Nome: ${produto.nome_produto} \nQuantidade: ${produto.quantidade} \nPreço de Compra: R$ ${produto.preco_compra}\n`,
    );
  }
}

const produtos: Produto[] = [
  { nome_produto: "Arroz", quantidade: 10, preco_compra: 5.99 },
  { nome_produto: "Feijão", quantidade: 5, preco_compra: 8.99 },
  { nome_produto: "Macarrão", quantidade: 3, preco_compra: 2.49 },
  { nome_produto: "Óleo", quantidade: 2, preco_compra: 3.99 },
  { nome_produto: "Sal", quantidade: 1, preco_compra: 1.49 },
];

listar_produtos(produtos);
