let fruta: string = 'maça';

if (fruta === 'maça') {
  console.log("A fruta é uma maça");
} else {
  console.log("A fruta não é uma maça, a fruta é " + fruta);
}
