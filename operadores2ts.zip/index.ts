const numero: number = 21;

const divisivelPorTres: boolean = numero % 3 === 0;
console.log(divisivelPorTres);