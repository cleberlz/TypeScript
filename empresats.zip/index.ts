/*1. Crie a CLASSE EMPRESA com os seguintes ATRIBUTOS/VARIAVEIS (nome_empresa, ramo_atividade). Crie a CLASSE SERVIÇOS com os ATRIBUTOS/VARIÁVEIS (tipo_servico, telefone, email). A CLASSE SERVIÇOS deverá herdar os atributos da CLASSE EMPRESA. Imprima no TERMINAL (nome_empresa, ramo_atividade, tipo_servico, telefone, email).*/

class Empresa {
  private nome_empresa: string;
  private ramo_atividade: string;

  constructor(nome_empresa: string, ramo_atividade: string) {
    this.nome_empresa = nome_empresa;
    this.ramo_atividade = ramo_atividade;
  }

  getNomeEmpresa() {
    return this.nome_empresa;
  }

  getRamoAtividade() {
    return this.ramo_atividade;
  }
}

class Servicos extends Empresa {
  tipo_servico: string;
  telefone: number;
  email: string;

  constructor(
    nome_empresa: string,
    ramo_atividade: string,
    tipo_servico: string,
    telefone: number,
    email: string,
  ) {
    super(nome_empresa, ramo_atividade);
    this.tipo_servico = tipo_servico;
    this.telefone = telefone;
    this.email = email;
  }

  listar() {
    console.log(`Nome da empresa: ${this.getNomeEmpresa()}
                \nRamo de atividade: ${this.getRamoAtividade()}
                \nTipo de serviço: ${this.tipo_servico}
                \nTelefone: ${this.telefone}
                \nEmail: ${this.email}`);
  }
}

const servicos: Servicos[] = [
  new Servicos(
    "Gerdau",
    "Metal",
    "Venda de metais",
    1234567890,
    "ztejd@example.com",
  ),
  new Servicos(
    "Amazon",
    "Varejo",
    "Vendas",
    9876543210,
    "ejeyd@example.com",
  ),
  new Servicos(
    "Jadlog",
    "Logistica",
    "Serviço de logistica",
    1111111111,
    "tugrp@example.com",
  ),
];

for (const s of servicos) {
  s.listar();
  console.log("----------------------------------");
}
