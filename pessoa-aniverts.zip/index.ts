/*
2. Calculando a idade de uma pessoa:
Crie uma classe Pessoa com os atributos nome e dataNascimento. Crie um método calcularIdade que calcula a idade da pessoa com base na data de nascimento.
*/

class Pessoa {
  // Atributos
  public nome: string;
  public dataNascimento: Date;

  // Métodos
  constructor(nome: string, dataNascimento: Date) {
    this.nome = nome;
    this.dataNascimento = new Date(dataNascimento);
  }
  calcularIdade() {
    const dataAtual = new Date();
    let idade = dataAtual - this.dataNascimento;
   // console.log(`Data atual: ${dataAtual.toISOString().split("T")[0]}`);

    //console.log(`Data nascimento: ${this.dataNascimento.toISOString().split("T")[0]}`);
      
    idade = Math.floor(idade / (1000 * 3600 * 24* 365));
    console.log(`Idade: ${idade} anos`);
  }
}
// Criando um objeto da classe Pessoa
const p = new Pessoa("Cléber Zancanaro", "1982-02-27");
// Acessando os atributos do objeto
console.log(p.nome);
// Chamando um método do objeto
p.calcularIdade();




