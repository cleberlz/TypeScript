/*
5. Crie uma classe ContaBancaria com os atributos numero, saldo e titular. Crie métodos para depositar, sacar e consultar o saldo.
*/
class ContaBancaria {
  numero: number;
  saldo: number;
  titular: string;
  
  constructor(numero: number, saldo: number, titular: string) {
    this.numero = numero;
    this.saldo = saldo;
    this.titular = titular;
  }
  
  depositar(valor: number): void {
    this.saldo += valor;
    console.log(`Deposito de R$ ${valor.toFixed(2)} realizado com sucesso`);
  }
  
  sacar(valor: number): void {
    if (valor > this.saldo) {
      console.log("Saldo insuficiente para saque");
    } else {
      this.saldo -= valor;
      console.log(`Saque de R$ ${valor.toFixed(2)} realizado com sucesso`);
    }
  }
  
  exibirSaldo(): void {
    console.log(`Seu saldo é R$ ${this.saldo.toFixed(2)}`);
  }
}

let conta = new ContaBancaria(123, 0, "João");

conta.exibirSaldo();
conta.depositar(250);
conta.exibirSaldo();
conta.sacar(100);
conta.exibirSaldo();
conta.depositar(50);
conta.exibirSaldo();
conta.sacar(500);
conta.exibirSaldo();
