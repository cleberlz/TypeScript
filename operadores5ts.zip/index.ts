const numero1: number = 3;
const numero2: number = 3;

const igual: boolean = numero1 == numero2;
console.log(igual);