let num : number = 15;

let par = num % 2 == 0;

if (par){
  console.log("O número " + num + " é par");
} else {
  console.log("O número " + num + " é ímpar");
}