/*
 03. Crie uma classe Veículos, com as propriedades privadas (nome-veiculo, placa, cor). Crie o método listarVeiculos e imprima na tela todos os veículos com a cor azul. (Crie 5 objetos diferentes para veículos).
 */

class Veiculos {
  private _nomeVeiculo: string;
  private _placa: string;
  private _cor: string;

  constructor(nomeVeiculo: string, placa: string, cor: string) {
    this._nomeVeiculo = nomeVeiculo;
    this._placa = placa;
    this._cor = cor;
  }

  listarVeiculos() {
    if (this._cor === "Azul") {
      console.log(
        `Nome do veículo: ${this._nomeVeiculo} \nPlaca: ${this._placa} \nCor: ${this._cor}`);
    } 
  }
}

const veiculo1 = new Veiculos("Lamborghini", "ABC123", "Azul");
const veiculo2 = new Veiculos("Jeep Compass", "DEF456", "Vermelho");
const veiculo3 = new Veiculos("Camaro", "GHI789", "Azul");
const veiculo4 = new Veiculos("Ferrari", "JKL012", "Vermelho");
const veiculo5 = new Veiculos("Mustang", "MNO345", "Azul");

console.log("Veículos azuis");
console.log(veiculo1.listarVeiculos());
console.log(veiculo2.listarVeiculos());
console.log(veiculo3.listarVeiculos());
console.log(veiculo4.listarVeiculos());
console.log(veiculo5.listarVeiculos());
